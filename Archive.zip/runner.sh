#!/usr/bin/env bash

python3 bootstrapper.py &

python3 client.py --file 1.json &
python3 client.py --file 2.json &
python3 client.py --file 3.json &
python3 client.py --file 4.json &
python3 client.py --file 5.json &
python3 client.py --file 6.json &
python3 client.py --file 7.json &
python3 client.py --file 8.json &
python3 client.py --file 9.json &
python3 client.py --file 10.json &
python3 client.py --file 11.json &
python3 client.py --file 12.json &
python3 client.py --file 13.json &
python3 client.py --file 14.json &
python3 client.py --file 15.json &
python3 client.py --file 16.json &
python3 client.py --file 17.json &
python3 client.py --file 18.json &
python3 client.py --file 19.json &
python3 client.py --file 20.json &