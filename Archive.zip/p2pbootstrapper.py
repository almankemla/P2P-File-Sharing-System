"""
Follow the instructions in each method and complete the tasks. We have given most of the house-keeping variables
that you might require, feel free to add more if needed. Hints are provided in some places about what data types 
can be used, others are left to user discretion, make sure that what you are returning from one method gets correctly
interpreted on the other end. 
"""
import socket
import threading
import sys
import pickle
import json
import random
from p2pclient import Status

class p2pbootstrapper:
    def __init__(self, ip='127.0.0.1', port=8888):
        ##############################################################################
        # TODO:  Initialize the socket object and bind it to the IP and port, refer  #
        #        https://docs.python.org/3/howto/sockets.html on how to do this.     #
        ##############################################################################
        
        

        self.boots_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.boots_socket.bind((ip, port))
        self.clients = []  # None for now, will get updates as clients register

        # Append the log to this variable.
        self.log = []
        self.action = 0

        # Timing variables:
        ###############################################################################################
        # TODO:  To track the time for all clients, self.time starts at 0, when all clients register  #
        #        self.MAX_CLIENTS is the number of clients we will be spinnign up. You can use this   #
        #        to keep track of how many 'complete' messages to get before incrementing time.       #
        #        CHange this when testing locally                                                     #
        ###############################################################################################
        self.time = 0
        self.MAX_CLIENTS = 20
        print(a)


    def start_listening(self):
        ##############################################################################
        # TODO:  This function will make the BS start listening on the port 8888     #
        #        Refer to                                                            #
        #        https://docs.python.org/3/howto/sockets.html on how to do this.     #
        #        You will need to link each connecting client to a new thread (using #
        #        client_thread function below) to handle the requested action.       #
        ##############################################################################

        self.boots_socket.listen(5)
        print(b)
        while True:
            (client_socket, address) = self.boots_socket.accept()

            clientThread = threading.Thread(target = self.client_thread, args = (client_socket, ))
            clientThread.start()

    def client_thread(self, client_socket):
        ##############################################################################
        # TODO:  This function should handle the incoming connection requests from   #
        #        clients. You are free to add more arguments to this function based  #
        #        on your need                                                        #
        #        HINT: After reading the input from the buffer, you can decide what  #
        #        action needs to be done. For example, if the client wants to        #
        #        deregister, call self.deregister_client                             #
        ##############################################################################

        while True :
            data = client_socket.recv(1024).decode('utf-8')
            data = data.replace('"', '')
            if data:
                data_arr = data.split(" ")
                client_id = data_arr[0]
                data = data_arr[1]
                ip = data_arr[2]
                port = data_arr[3]

                if data == 'U' :
                    self.deregister_client(client_id, ip, port)
                    self.process_action_complete(data):
                elif data == 'R' :
                    self.register_client(client_id, ip, port, client_socket)
                    self.process_action_complete(data):
                elif data == 'S':
                    self.start()
                elif data == 'Complete':
                    self.process_action_complete(data):
                elif data == 'AllClients':
                    client_list = self.return_clients()
                    sorted_list = sorted(client_list, key=lambda x: x[0]) 
                    send = json.dumps(sorted_list)

                    clientsocket.send(send.encode('utf-8'))
            

                     

    def register_client(self, client_id, ip, port, status):  
        ##############################################################################
        # TODO:  Add client to self.clients                                          #
        ##############################################################################
        print("Bootstrapper register client")
        self.clients.append((client_id, ip, port, status))

    def deregister_client(self, client_id, ip, port, status):
        ##############################################################################
        # TODO:  Delete client from self.clients                                     #
        ##############################################################################
        print("Bootstrapper deregister client")
        self.clients.remove((client_id, ip, port, status))

    def return_clients(self):
        ##############################################################################
        # TODO:  Return self.clients                                                 #
        ##############################################################################
        print("Bootstrapper return clients")
        return self.clients

    def start(self):
        ##############################################################################
        # TODO:  Start timer for all clients so clients can start performing their   #
        #        actions                                                             #
        ##############################################################################
        print("Bootstrapper start")
        self.time += 1
        if self.actions >= 7:
            return
        for client in self.clients:
            client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client_socket.connect((client[1], int(client[2])))

            send = str(str(20) + ' S '+ '127.0.0.1' +' '+str(8888))
            client_socket.send(send.encode('utf-8'))

            client_socket.close()

    def process_action_complete(self):
        ##############################################################################
        # TODO:  Process the 'action complete' message from a client,update time if  #
        #        all clients are done, inform all clients about time increment       #
        ##############################################################################
        print("process_action_complete")
        text = ""
        self.action += 1
        if self.action == MAX_CLIENTS:
            self.action = 0
            for client in client_list:
                client_id, ip, port, status = client['client_id'], '127.0.0.1', client['port'], client['status']
                if status == Status.REGISTERED:
                    text += f'<{client_id}, {ip}, {port}>, '
                self.log.append({"time": self.time, "text": "Clients registered: " + clients_text[: len(clients_text) - 2]})
        with open(string, "w") as json_file:
            json.dump(self.log, json_file)

        self.start()
                
            